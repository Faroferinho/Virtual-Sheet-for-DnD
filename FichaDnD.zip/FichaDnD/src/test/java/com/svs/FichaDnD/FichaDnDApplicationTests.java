package com.svs.FichaDnD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FichaDnDApplicationTests {

	@Test
	void contextLoads() {
	}

}
